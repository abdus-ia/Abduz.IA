---
name: SGA Tactical Deep Space
colors:
  surface: '#0f1419'
  surface-dim: '#0f1419'
  surface-bright: '#353a3f'
  surface-container-lowest: '#0a0f14'
  surface-container-low: '#171c21'
  surface-container: '#1b2025'
  surface-container-high: '#252a30'
  surface-container-highest: '#30353b'
  on-surface: '#dee3ea'
  on-surface-variant: '#b9cbbc'
  inverse-surface: '#dee3ea'
  inverse-on-surface: '#2c3137'
  outline: '#849587'
  outline-variant: '#3b4a3f'
  surface-tint: '#00e389'
  primary: '#ccffd9'
  on-primary: '#00391e'
  primary-container: '#03f594'
  on-primary-container: '#006b3e'
  inverse-primary: '#006d3f'
  secondary: '#67dbb2'
  on-secondary: '#003829'
  secondary-container: '#23a37e'
  on-secondary-container: '#003123'
  tertiary: '#e8f5ff'
  on-tertiary: '#00354a'
  tertiary-container: '#a8deff'
  on-tertiary-container: '#006488'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#57ffa6'
  primary-fixed-dim: '#00e389'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#00522e'
  secondary-fixed: '#85f8cd'
  secondary-fixed-dim: '#67dbb2'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513c'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0f1419'
  on-background: '#dee3ea'
  surface-variant: '#30353b'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

O design system estabelece a linguagem visual e tática do SGA (Sistema de Gestão de Abduções e Operações Interplanetárias). O produto opera em cenários de alta pressão, decisão crítica e coordenação de frotas estelares em tempo real. A experiência deve transmitir precisão cirúrgica, prontidão de combate, controle militar-científico e inteligência tática avançada.

### Filosofia Estética: Minimalismo Militar Cibernético (Sci-Fi Precision)
A estética funde a disciplina de displays táticos head-up (HUD) e painéis de telemetria orbital com a ergonomia do software moderno de missão crítica:
- **Atmospheric Deep-Space Dark Mode**: Imersão visual contínua sem quebras bruscas de luminescência, priorizando a redução da fadiga ocular em turnos prolongados.
- **Micro-estruturas de Vetores e Metadados**: Cada card, tela e botão possui propósitos funcionais declarados; elimina-se qualquer elemento puramente decorativo sem carga de informação.
- **Hierarquia de Alerta em Camadas**: Uso cirúrgico de fósforo neon alienígena (`#03F594`) e sinalizadores críticos para leitura imediata em menos de 200ms de escaneamento visual.
- **Ergonomia Operacional Tática**: Áreas de toque generosas em dispositivos de campo/mobile combinadas a alta densidade de métricas em desktops de comando orbital.

## Colors

A matriz cromática baseia-se em luminescência controlada sobre um espectro abissal escuro, garantindo contraste estrito em conformidade com WCAG 2.1 AA/AAA em todas as leituras críticas de dados.

### Superfícies & Neutros (Deep Space Palette)
- **Canvas Base / Fundo Cósmico**: `#0A0F14` — Vácuo primário, tela de fundo de dashboards e views táticas.
- **Surface Level 1 / Painéis & Hangar**: `#111B24` — Base de cards operacionais, gavetas de missão e sidebars.
- **Surface Level 2 / Módulos Flutuantes & HUD**: `#16232F` — Destaques internos de cards, cabeçalhos de tabela e inputs desativados.
- **Ghost Border / Limiares de Contenção**: `#1C2B38` — Delimitação estrutural técnica de baixíssima opacidade luminosa.
- **Border Focus / Linha Ativa**: `#2E465B` — Divisores em foco e contornos de agrupamento.

### Assinatura Tática & Sinalização Neon
- **Primary / Alien Bio-Neon (`#03F594`)**: Sinal de sistema ativo, telemetria nominal, espécimes catalogados, botão de comando principal e confirmações de salto hiperespacial.
- **Secondary / Plasma Balance (`#4BC19A`)**: Métricas de suporte, estados intermediários, escudos operacionais secundários e links contextuais.
- **Text & Core Indicators (`#FBFBFB`)**: Tipografia principal, valores escalares críticos e índices de telemetria imediata.
- **Text Muted / Metadados (`#7E95A6`)**: Subtítulos técnicos, carimbos de data/hora estelar (stardate) e unidades de medida física.

### Espectro Funcional e Protocolos de Risco
- **Alerta / Protocolo Âmbar (`#FFB020`)**: Anomalias gravitacionais, combustores em superaquecimento, autorizações pendentes.
- **Perigo / Protocolo Quarentena & Bloqueio (`#FF4D4D`)**: Contaminação biológica, espécime hostil em fuga, quebra de casco, recusa de evacuação.
- **Reparo & Telemetria Téc. (`#38BDF8`)**: Hangar de naves, balanceamento de motores de dobra, diagnósticos de hardware.

## Typography

A tipografia combina a neutralidade de alta precisão do **Geist** para fluxos gerais, listas e tomadas de decisão estruturadas com o rigor instrumental monospaçado do **JetBrains Mono** para identificadores táticos, carimbos temporais, coordenadas estelares e telemetrias instantâneas.

### Regras de Emprego
1. **Dados Numéricos & Coordenadas**: Todas as leituras de telemetria, vetores de propulsão, percentuais de escudo e contagens regressivas devem obrigatoriamente renderizar em `JetBrains Mono` com recurso `tabular-nums` ativo.
2. **Textos de Protocolo**: Títulos de status de quarentena, perfis de patrulha e ordens de comandante utilizam `Geist` com rastreamento levemente negativo para máxima densidade de leitura.
3. **Micro-Identificadores Táticos**: Tokens como `[AUT-ORB-92]` ou `SEC-LEVEL-04` utilizam `label-mono-sm` em caixa alta com espaçamento entre letras acentuado (`letterSpacing: 0.08em`).

## Layout & Spacing

O layout do SGA adota uma grade fluida e modular desenhada sob um ritmo de 4px / 8px, estruturada para renderizar painéis de controle densos em estações de batalha e manter operações mobile seguras mesmo com uma única mão.

### Arquitetura de Telas e Dispositivos
- **Console Desktop / Ponte de Comando (>= 1280px)**: Grid de 12 colunas fluidas com 24px de calha (`gutter-desktop`). Permite visão tripla simultânea: Telemetria de Esquadra, Feed de Satélites de Extração e Painel de Quarentena.
- **Terminal Tablet / Hangar Portátil (768px - 1279px)**: Grid de 8 colunas fluidas, agrupamento de cartões de manutenção em grids de 2 colunas e menus laterais retráteis por gaveta deslizante.
- **Mobile de Campo / Equipamento Tático (< 768px)**: Grid de 4 colunas fluidas com margem de 16px. Todos os botões primários de confirmação e disparo residem na zona inferior da tela (Thumb-Zone), ancorados em barras de ação fixas com proteção de área segura (safe-area).

## Elevation & Depth

No ambiente de vácuo profundo do SGA, a elevação é puramente física e luminotécnica: não se aplicam sombras difusas convencionais baseadas em luz zenital suave. Em vez disso, a profundidade é expressa por **camadas tonais de superfície**, **bordas de contenção micrométricas** e **halos de refração neon**.

### Níveis de Profundidade
1. **Piso Operacional (Fundo - #0A0F14)**: Camada de base estática sem contorno.
2. **Plataformas & Módulos (Cards de Telemetria e Hangares - #111B24)**: Borda perimetral de 1px em `#1C2B38`. Zero sombra difusa em repouso. Transmite rigidez de chassi de espaçonave.
3. **Sobreposição Tática & Menus Flutuantes (#16232F)**: Borda perimetral de 1px em `#2E465B`, acompanhada de uma sombra sutil projetada: `0 8px 24px rgba(0, 0, 0, 0.65)`.
4. **Halos de Campo de Força (Estados de Foco / Quarentena / Alerta)**:
   - *Status Nominal / Primário*: Borda iluminada `#03F594` acompanhada de brilho perimetral neon `0 0 12px rgba(3, 245, 148, 0.25)`.
   - *Bloqueio Crítico / Quarentena*: Borda ativa `#FF4D4D` com pulso em gradiente `0 0 16px rgba(255, 77, 77, 0.35)`.
   - *Inspeção / Reparo*: Borda ativa `#38BDF8` com reflexo suave `0 0 10px rgba(56, 189, 248, 0.2)`.

## Shapes

O design system adota o nível de arredondamento **Soft (1)**. Componentes padrão possuem raio de curvatura de 4px (`rounded`), enquanto cartões de hangar, gavetas de missão e diálogos de autorização dupla usam 8px (`rounded-lg`).

### Razão Tática da Forma
- Elementos excessivamente arredondados ou em formato de pílula transmitem casualidade e reduzem a área útil para visualização de logs numéricos. 
- O corte chanfrado e sutil de 4px a 8px preserva o caráter técnico-militar, assemelhando-se a visores de proteção balística e invólucros de ligas metálicas aeroespaciais.
- Badges de pulso e marcadores de status circulares são reservados exclusivamente para luzes de telemetria LED miniatura (diâmetros de 6px a 10px).

## Components

### 1. Botões Operacionais
- **Primário (Ação Crítica de Missão)**: Fundo `#03F594`, texto `#0A0F14` em `Geist` semi-bold (600). Hover com brilho sutil; active com escala de 0.98.
- **Secundário (Controle de Manobra)**: Fundo transparente, borda de 1px em `#4BC19A`, texto `#4BC19A`. Hover com preenchimento em `rgba(75, 193, 154, 0.1)`.
- **Destrutivo / Abortar**: Fundo transparente com borda de 1px em `#FF4D4D`, texto `#FF4D4D`. Usado para cancelamento de salto orbital e purga de câmaras.

### 2. Badges de Status com Pulso Tático
- Composto por: Ponto de LED (8px) + Rótulo em `JetBrains Mono` 10px.
- **Status Nominal**: LED `#03F594` pulsando ciclicamente (animação suave de 2s via box-shadow com dispersão de 6px).
- **Status Alerta Gravitacional**: LED `#FFB020` em pulso rítmico intermediário (1.2s).
- **Status Quarentena Ativa**: LED `#FF4D4D` em estroboscópio duplo tático (0.6s).
- **Status Hangar / Manutenção**: LED contínuo `#38BDF8` sem pulso.

### 3. Cards de Telemetria Rápida
- Fundo `#111B24`, borda estrutural `#1C2B38` de 1px.
- Cabeçalho: Identificador do espécime ou nave em `label-mono-sm` e badge de status no canto superior direito.
- Núcleo: Grande métrica numérica em `display-hero-mobile` com unidade monospaçada reduzida.
- Rodapé: Minigráfico vetorial de faixas ou microbarra de integridade de escudo com 4px de altura.

### 4. Seletor de Perfil de Acesso Tático
- Permite alternar papéis: **Comandante**, **Gerente**, **Piloto**, **Tripulação**.
- Layout em grade segmentada compacta. O perfil selecionado recebe fundo `#16232F`, borda `#03F594` e ícone correspondente iluminado.
- Exibe o nível de autorização militar em formato tag: `[LVL-ALPHA]`, `[LVL-BETA]`, `[LVL-DELTA]`, `[LVL-EPSILON]`.

### 5. Formulários com Checklist de Autorização Dupla
- Campos de entrada: Fundo `#0E141B`, borda `#1C2B38`, texto `#FBFBFB` e placeholder `#7E95A6`. Em foco: borda `#03F594`.
- **Módulo de Dupla Validação**:
  - Exige confirmação independente: "Autorização do Oficial Tático" + "Assinatura Biométrica do Comandante".
  - Checkboxes operacionais: Caixas quadradas de 18px com borda `#2E465B`. Ao marcar, preenchem-se com `#03F594` exibindo um glifo vetorial geométrico centralizado.

### 6. Painel de Quarentena e Bloqueio de Tripulantes / Espécimes
- Card de contenção máxima: Fundo `#141014` com borda lateral esquerda de 4px em `#FF4D4D`.
- Título em caixa alta com carimbo de estanqueidade `ISOLATION PROTOCOL ENGAGED`.
- Botão de destravamento com proteção anti-acidente (manter pressionado por 3 segundos com barra de progresso visual em preenchimento contínuo).

### 7. Monitor de Status de Hangar & Manutenção
- Tabela com linhas zebradas sutis (`#111B24` intercalado com `#0E151D`).
- Indicadores visuais do estado das docas: `Doca A-01: Livre`, `Doca B-04: Reconfigurando Núcleo de Dobra` (em `#38BDF8`).
- Barras de combustível hiperespacial com preenchimento segmentado em blocos discretos de 10% para conferência instantânea.